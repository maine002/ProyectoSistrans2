ALTER TABLE servicio_salud ADD clazz_ VARCHAR2(255);
ALTER TABLE servicio_salud ADD tipo_servicio VARCHAR2(255);

SELECT receta FROM CONSULTA_GENERAL;

DROP TABLE servicio_salud CASCADE CONSTRAINTS;
DROP TABLE consulta_general CASCADE CONSTRAINTS;

CREATE TABLE servicio_salud (
    id NUMBER PRIMARY KEY,
    nombre VARCHAR2(255),
    fecha DATE,
    hora VARCHAR2(10)
);

CREATE TABLE consulta_general (
    id NUMBER PRIMARY KEY,
    receta VARCHAR2(255),
    CONSTRAINT fk_consulta_general FOREIGN KEY (id) REFERENCES servicio_salud(id)
);


DROP TABLE prestacion_servicio CASCADE CONSTRAINTS;
CREATE TABLE prestacion_servicio (
    id NUMBER PRIMARY KEY,
    afiliado_id NUMBER NOT NULL,
    servicio_id NUMBER NOT NULL,
    medico_id VARCHAR2(100) NOT NULL,
    ips_nit VARCHAR2(100) NOT NULL,
    fecha DATE NOT NULL,
    hora VARCHAR2(10) NOT NULL,
    CONSTRAINT fk_prestacion_servicio_afiliado FOREIGN KEY (afiliado_id) REFERENCES afiliado(id),
    CONSTRAINT fk_prestacion_servicio_servicio FOREIGN KEY (servicio_id) REFERENCES servicio_salud(id)
);

-- Crear la secuencia para IDs automáticos
CREATE SEQUENCE PRESTACION_SEQ
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;


