
-- 1. Insertar un médico (usa String como PK: numeroRegistro)
INSERT INTO medico (numero_registro, nombre, tipo_documento, numero_documento, especialidad)
VALUES ('M-001', 'Dr. Juan Pérez', 'CC', '123456789', 'Medicina General');

-- 2. Insertar una EPS (necesaria para el afiliado)
INSERT INTO eps (id, nombre)
VALUES (1, 'Salud Total');

-- 3. Insertar un afiliado (usa ID autogenerado, pero eps_id es obligatorio)
INSERT INTO afiliado (id, nombre, tipo_documento, numero_documento, fecha_nacimiento, direccion, telefono, eps_id)
VALUES (1001, 'Ana López', 'CC', '987654321', DATE '1990-01-01', 'Calle Falsa 123', '3110000000', 1);

-- 4. Insertar una orden de servicio (relaciona afiliado y médico)
INSERT INTO orden_servicio (orden_id, fecha, estado, orden_previa_id, afiliado_id, medico_id)
VALUES (2001, CURRENT_DATE, 'ACTIVA', 0, 1001, 'M-001');

-- 5. Insertar un agendamiento (relaciona la orden y un servicio existente)
-- Reemplaza 3001 con el ID de un servicio ya existente en tu base de datos
INSERT INTO agendamiento (id, orden_id, servicio_id, fecha, hora, realizado, observaciones)
VALUES (4001, 2001, 4, CURRENT_DATE + 3, TO_TIMESTAMP('10:00:00', 'HH24:MI:SS'), 0, 'Prueba agendamiento RFC');

commit;

-- Ver EPS existentes
SELECT * FROM eps;

SELECT * FROM orden_servicio WHERE orden_id = 2001;

SELECT * FROM agendamiento ORDER BY id;

SELECT * FROM agendamiento WHERE servicio_id = 4 ORDER BY fecha, hora;


