BEGIN
  FOR t IN (
    SELECT table_name
    FROM user_tables
    WHERE table_name LIKE 'HT_%' OR table_name LIKE 'HTE_%'
  ) LOOP
    EXECUTE IMMEDIATE 'DROP TABLE "' || t.table_name || '" CASCADE CONSTRAINTS';
  END LOOP;
END;
/

ALTER TABLE servicio_salud ADD tipo_servicio VARCHAR2(31);
UPDATE servicio_salud SET tipo_servicio = 'GENÉRICO';
ALTER TABLE servicio_salud MODIFY tipo_servicio VARCHAR2(31) NOT NULL;