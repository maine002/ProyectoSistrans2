package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "consulta_control")
@DiscriminatorValue("consulta_control")
public class ConsultaControlEntity extends ServicioSaludEntity {

    @Column
    private String receta;

    public ConsultaControlEntity() {}

    public ConsultaControlEntity(String receta) {
        this.receta = receta;
    }

    public String getReceta() {
        return receta;
    }

    public void setReceta(String receta) {
        this.receta = receta;
    }
}

