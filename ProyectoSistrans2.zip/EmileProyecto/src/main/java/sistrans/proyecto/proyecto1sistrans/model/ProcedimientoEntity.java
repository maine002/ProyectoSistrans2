package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "procedimiento")
@DiscriminatorValue("procedimiento")
public class ProcedimientoEntity extends ServicioSaludEntity {

    @Column(nullable = false)
    private String tipo;

    public ProcedimientoEntity() {}

    public ProcedimientoEntity(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
