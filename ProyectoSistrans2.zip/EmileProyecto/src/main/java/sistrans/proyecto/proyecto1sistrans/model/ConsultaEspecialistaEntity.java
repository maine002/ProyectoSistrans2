package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "consulta_especialista")
@DiscriminatorValue("consulta_especialista")
public class ConsultaEspecialistaEntity extends ServicioSaludEntity {

    @Column
    private String receta;

    public ConsultaEspecialistaEntity() {}

    public ConsultaEspecialistaEntity(String receta) {
        this.receta = receta;
    }

    public String getReceta() {
        return receta;
    }

    public void setReceta(String receta) {
        this.receta = receta;
    }
}

