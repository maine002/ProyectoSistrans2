package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "medico_ips") 
public class TrabajaIPSEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "medico_id", nullable = false)
    private MedicoEntity medico;

    @ManyToOne
    @JoinColumn(name = "ips_nit", nullable = false)
    private IpsEntity ips;

    // Constructor vacío
    public TrabajaIPSEntity() {}

    // Constructor completo
    public TrabajaIPSEntity(MedicoEntity medico, IpsEntity ips) {
        this.medico = medico;
        this.ips = ips;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public MedicoEntity getMedico() {
        return medico;
    }

    public void setMedico(MedicoEntity medico) {
        this.medico = medico;
    }

    public IpsEntity getIps() {
        return ips;
    }

    public void setIps(IpsEntity ips) {
        this.ips = ips;
    }
}
