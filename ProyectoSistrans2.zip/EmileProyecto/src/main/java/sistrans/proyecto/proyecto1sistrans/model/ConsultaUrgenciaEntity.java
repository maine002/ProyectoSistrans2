package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "consulta_urgencia")
@DiscriminatorValue("consulta_urgencia")
public class ConsultaUrgenciaEntity extends ServicioSaludEntity {

    @Column
    private String receta;

    @Column(nullable = false)
    private String triage;

    public ConsultaUrgenciaEntity() {}

    public ConsultaUrgenciaEntity(String receta, String triage) {
        this.receta = receta;
        this.triage = triage;
    }

    public String getReceta() {
        return receta;
    }

    public void setReceta(String receta) {
        this.receta = receta;
    }

    public String getTriage() {
        return triage;
    }

    public void setTriage(String triage) {
        this.triage = triage;
    }
}

