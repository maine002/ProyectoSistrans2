package sistrans.proyecto.proyecto1sistrans.routes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.web.bind.annotation.*;
import sistrans.proyecto.proyecto1sistrans.logic.AgendamientoLogic;
import sistrans.proyecto.proyecto1sistrans.model.AgendamientoEntity;
import sistrans.proyecto.proyecto1sistrans.model.OrdenServicioEntity;
import sistrans.proyecto.proyecto1sistrans.model.ServicioSaludEntity;
import java.util.Optional;
import java.util.Map;
import java.util.List;
import sistrans.proyecto.proyecto1sistrans.logic.OrdenServicioLogic;


import org.springframework.transaction.annotation.Transactional;


import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;


@RestController
@RequestMapping("/agendamientos")
public class AgendamientoRoute {

    @Autowired
    private AgendamientoLogic logic;
    
    @Autowired
    private OrdenServicioLogic ordenServicioLogic; 

    // RFC1 - Consulta disponibilidad para las próximas 4 semanas
    @GetMapping("/servicio/disponibilidad")
    public Collection<AgendamientoEntity> getDisponibilidadProximas4Semanas(
            @RequestParam("servicio_id") Long servicioId) {
        return logic.consultarDisponibilidadServicioProximas4Semanas(servicioId);
    }
    

    // RFC6 - Consulta con filtros (READ COMMITTED + timeout 30s)
    @GetMapping("/filtros")
    public Collection<AgendamientoEntity> getAgendaConFiltros(
            @RequestParam("idServicio") Long idServicio,
            @RequestParam("idMedico") String idMedico,
            @RequestParam("idAfiliado") Long idAfiliado,
            @RequestParam("fechaInicio") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
            @RequestParam("fechaFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin
    ) {
        return logic.consultarAgendaConFiltros(idServicio, idMedico, idAfiliado, fechaInicio, fechaFin);
    }

    //Para el RF7
    @PostMapping("/crear")
    public String crearAgendamiento(
            @RequestParam Boolean realizado,
            @RequestParam Long servicio_id,
            @RequestParam String fecha,
            @RequestParam String hora,
            @RequestParam Long orden_id,
            @RequestParam(required = false) String observaciones) {
        try {
            // Convertir fecha y hora de String a LocalDate y LocalTime
            LocalDate fechaParsed = LocalDate.parse(fecha);
            LocalTime horaParsed = LocalTime.parse(hora);

            logic.insertAgendamiento(realizado, servicio_id, fechaParsed, horaParsed, orden_id, observaciones);
            return "Agendamiento registrado exitosamente.";
        } catch (Exception e) {
            return "Error al registrar agendamiento: " + e.getMessage();
        }
    }

    // RF 9 

    @PutMapping("/realizado")
    public String agendamientorealizado(
            @RequestParam Long servicioId,
            @RequestParam Boolean realizado,
            @RequestParam Long orden_id,
            @RequestParam Long id) {
        try {
            logic.updateRealizado(realizado,servicioId,orden_id,id);
            return "Prestacion del servicio registrada";
        } catch (Exception e){
            return "Prestacion del servicio no registrada por un error" + e;
        }
        
    }

    // RF9 - Agendar servicio de salud de manera transaccional
    @PostMapping("/agendar-transaccional")
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public String agendarTransaccional(
            @RequestParam Long ordenId,
            @RequestParam Long servicioId,
            @RequestParam String fecha,
            @RequestParam String hora
    ) {
        try {
            // Validar que la orden realmente exista
            Optional<OrdenServicioEntity> ordenOptional = ordenServicioLogic.findById(ordenId);
            if (ordenOptional.isEmpty()) {
                throw new RuntimeException("La orden médica con ID " + ordenId + " no existe.");
            }
            OrdenServicioEntity orden = ordenOptional.get();

            // Verificar si ya existe un agendamiento para ese servicio en esa fecha y hora
            Collection<AgendamientoEntity> existentes = logic.buscarAgendamientosPorServicioFechaHora(servicioId, fecha, hora);
            if (!existentes.isEmpty()) {
                throw new RuntimeException("El espacio ya fue ocupado, no se puede agendar.");
            }

            // Crear nuevo agendamiento
            AgendamientoEntity nuevoAgendamiento = new AgendamientoEntity();
            nuevoAgendamiento.setOrden(orden);

            ServicioSaludEntity servicio = new ServicioSaludEntity();
            servicio.setId(servicioId);

            nuevoAgendamiento.setServicio(servicio);
            nuevoAgendamiento.setFecha(LocalDate.parse(fecha));
            nuevoAgendamiento.setHora(LocalTime.parse(hora));
            nuevoAgendamiento.setRealizado(false);

            logic.save(nuevoAgendamiento);

            return "Agendamiento exitoso (transacción completada).";
        } catch (Exception e) {
            throw new RuntimeException("Error en el agendamiento transaccional: " + e.getMessage(), e);
        }
    }

//RFC5 este va en agendamientoRoute
@GetMapping("/filtros/serializable")
public Collection<AgendamientoEntity> getAgendaConFiltrosSerializable(
        @RequestParam("idServicio") Long idServicio,
        @RequestParam("idMedico") String idMedico,
        @RequestParam("idAfiliado") Long idAfiliado,
        @RequestParam("fechaInicio") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
        @RequestParam("fechaFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin
) {
    return logic.consultarAgendaConFiltrosSerializable(idServicio, idMedico, idAfiliado, fechaInicio, fechaFin);
}

//RFC4 AgendamientoRoute
    @GetMapping("/utilizacion-afiliado")
    public List<Map<String, Object>> obtenerUtilizacionServiciosAfiliado(
            @RequestParam("afiliadoId") Long afiliadoId,
            @RequestParam("fechaInicio") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
            @RequestParam("fechaFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin
    ) {
        List<Object[]> resultados = logic.obtenerUtilizacionServiciosAfiliado(afiliadoId, fechaInicio, fechaFin);

        List<Map<String, Object>> respuesta = new ArrayList<>();
        for (Object[] fila : resultados) {
            Map<String, Object> map = new HashMap<>();
            map.put("nombreServicio", fila[0]);
            map.put("fechaServicio", fila[1]);
            map.put("nombreMedico", fila[2]);
            map.put("nombreIps", fila[3]);
            respuesta.add(map);
    }
        return respuesta;
}

}
