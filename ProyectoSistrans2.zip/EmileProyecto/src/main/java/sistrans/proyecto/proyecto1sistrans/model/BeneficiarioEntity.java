package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "beneficiario")
public class BeneficiarioEntity extends AfiliadoEntity {

    @Column(nullable = false)
    private String parentesco;

    // Constructors
    public BeneficiarioEntity() {}

    public BeneficiarioEntity(String parentesco) {
        this.parentesco = parentesco;
    }

    // Getter and Setter
    public String getParentesco() {
        return parentesco;
    }

    public void setParentesco(String parentesco) {
        this.parentesco = parentesco;
    }
}
