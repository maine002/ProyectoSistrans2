package sistrans.proyecto.proyecto1sistrans.routes;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import sistrans.proyecto.proyecto1sistrans.logic.IPSLogic;
import sistrans.proyecto.proyecto1sistrans.model.IpsEntity;

import org.springframework.web.bind.annotation.RequestParam;

// RF1 Registrar una IPS

@RestController
@RequestMapping("/ips")
public class IPSRoute {
    @Autowired
    private IPSLogic logic;
    @GetMapping("/all")
    public Collection<IpsEntity> darIps() {
        return logic.darIps();
    }
   
    @PostMapping("/crear")
    public void crearIps(@RequestParam String nit,
                         @RequestParam String nombre,
                         @RequestParam String direccion,
                         @RequestParam String telefono,
                         @RequestParam Long eps_id){
    logic.insertIps(nit, nombre, direccion, telefono, eps_id);
    }
}
    
    

