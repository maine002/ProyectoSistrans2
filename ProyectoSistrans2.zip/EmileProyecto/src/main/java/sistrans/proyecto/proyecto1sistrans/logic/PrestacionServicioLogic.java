package sistrans.proyecto.proyecto1sistrans.logic;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import sistrans.proyecto.proyecto1sistrans.model.PrestacionServicioEntity;

// Para el RF8 Registrar la prestación de un servicio de salud a un afiliado por parte de una IPS

public interface PrestacionServicioLogic extends JpaRepository<PrestacionServicioEntity, Long> {

    @Query(value = "SELECT * FROM prestacion_servicio", nativeQuery = true)
    Collection<PrestacionServicioEntity> darPrestaciones();

    @Modifying
    @Transactional
    @Query(value = """
        INSERT INTO prestacion_servicio (id, afiliado_id, servicio_id, medico_id, ips_nit, fecha, hora)
        VALUES (PRESTACION_SEQ.NEXTVAL, :afiliadoId, :servicioId, :medicoId, :ipsNit, :fecha, :hora)
    """, nativeQuery = true)
    void insertarPrestacion(
        @Param("afiliadoId") Long afiliadoId,
        @Param("servicioId") Long servicioId,
        @Param("medicoId") String medicoId,
        @Param("ipsNit") String ipsNit,
        @Param("fecha") java.sql.Date fecha,
        @Param("hora") String hora
    );
}