package sistrans.proyecto.proyecto1sistrans.logic;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jakarta.transaction.Transactional;
import sistrans.proyecto.proyecto1sistrans.model.IpsServicioSaludEntity;

//RF3 Asignar un servicio de salud a una IPS

public interface IPSServicioSaludLogic extends JpaRepository<IpsServicioSaludEntity, Long> {
    @Query(value= "SELECT * FROM ips_servicio_salud", nativeQuery = true)
    Collection<IpsServicioSaludEntity> getIpsServicioSalud();

    @Modifying 
    @Transactional
    @Query(value= "INSERT INTO ips_servicio_salud (ips_nit, servicio_id) VALUES (:ips_nit, :servicio_id)", nativeQuery = true)
    void insertIpsServicioSalud(@Param("ips_nit") String ips_nit, @Param("servicio_id") Long servicio_id);

    
}
