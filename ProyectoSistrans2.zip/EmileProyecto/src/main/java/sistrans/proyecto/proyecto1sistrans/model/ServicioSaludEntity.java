package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Entity
@Table(name = "servicio_salud")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "tipo_servicio", discriminatorType = DiscriminatorType.STRING)
public class ServicioSaludEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "servicio_seq_gen")
    @SequenceGenerator(name = "servicio_seq", sequenceName = "SERVICIO_SEQ", allocationSize = 1)
    private Long id;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private LocalDate fecha;

    @Column(nullable = false)
    private LocalTime hora;

    @OneToMany(mappedBy = "servicio", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<IpsServicioSaludEntity> ipsAsociadas;
    
    @OneToMany(mappedBy = "servicio", cascade = CascadeType.ALL)
    private List<AgendamientoEntity> agendamientos;

    
    // Constructors
    public ServicioSaludEntity() {}

    public ServicioSaludEntity(String nombre, LocalDate fecha, LocalTime hora) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.hora = hora;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }
}
