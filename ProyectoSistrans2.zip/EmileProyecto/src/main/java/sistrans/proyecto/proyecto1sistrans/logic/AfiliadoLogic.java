package sistrans.proyecto.proyecto1sistrans.logic;

import java.time.LocalDate;
import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import sistrans.proyecto.proyecto1sistrans.model.AfiliadoEntity;

//RF5 Registrar un afiliado

public interface AfiliadoLogic extends JpaRepository<AfiliadoEntity, Long> {

    @Query(value = "SELECT * FROM afiliado", nativeQuery = true)
    Collection<AfiliadoEntity> darAfiliados();

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO afiliado (id, nombre, tipo_documento, numero_documento, fecha_nacimiento, direccion, telefono, eps_id) " +
                   "VALUES (:id, :nombre, :tipoDocumento, :numeroDocumento, :fechaNacimiento, :direccion, :telefono, :epsId)", nativeQuery = true)
                   void insertAfiliado(
                    @Param("id") Long id,
                    @Param("nombre") String nombre,
                    @Param("tipoDocumento") String tipoDocumento,
                    @Param("numeroDocumento") String numeroDocumento,
                    @Param("fechaNacimiento") LocalDate fechaNacimiento,
                    @Param("direccion") String direccion,
                    @Param("telefono") String telefono,
                    @Param("epsId") Long epsId
                );
}
