package sistrans.proyecto.proyecto1sistrans.routes;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import sistrans.proyecto.proyecto1sistrans.logic.ServicioSaludLogic;
import sistrans.proyecto.proyecto1sistrans.model.ServicioSaludEntity;

import org.springframework.web.bind.annotation.RequestParam;


// RF2 Registrar un servicio de salud

@RestController
@RequestMapping("/servicios")
class ServicioSaludRoute {
    @Autowired
    private ServicioSaludLogic logic;

    @GetMapping("/all")
    public Collection<ServicioSaludEntity> darServicios() {
        return logic.darServicioSalud();
    }

    @PostMapping("/crear")
    public void registrarServicio(@RequestParam String nombre,
                                  @RequestParam Date fecha,
                                  @RequestParam Time hora,
                                  @RequestParam String tipo_servicio) {
        logic.insertarServicio(nombre,fecha,hora,tipo_servicio);
    }
//RFC2 ServicioSaludRoute
    @GetMapping("/top-servicios")
    public List<Map<String, Object>> getServiciosMasSolicitados(
    @RequestParam("fechaInicio") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
    @RequestParam("fechaFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin
    ) {
    List<Object[]> resultados = logic.serviciosMasSolicitados(fechaInicio, fechaFin);

    List<Map<String, Object>> respuesta = new ArrayList<>();
    for (Object[] fila : resultados) {
        Map<String, Object> map = new HashMap<>();
        map.put("servicioId", fila[0]);
        map.put("usos", fila[1]);
        respuesta.add(map);
    }

    return respuesta;
    }

//RFC3 ServicioSaludRoute
@GetMapping("/indice-uso")
public List<Map<String, Object>> getIndiceUsoServicios(
@RequestParam("fechaInicio") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
@RequestParam("fechaFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin
) {
List<Object[]> resultados = logic.indiceUsoServicios(fechaInicio, fechaFin);

List<Map<String, Object>> respuesta = new ArrayList<>();
for (Object[] fila : resultados) {
    Map<String, Object> map = new HashMap<>();
    map.put("servicioId", fila[0]);
    map.put("usados", fila[1]);
    map.put("disponibles", fila[2]);
    map.put("indiceUso", fila[3]);
    respuesta.add(map);
}

return respuesta;
}    
}
