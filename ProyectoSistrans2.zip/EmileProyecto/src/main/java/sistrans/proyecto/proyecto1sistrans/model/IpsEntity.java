package sistrans.proyecto.proyecto1sistrans.model;

import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name = "ips")
public class IpsEntity {

    @Id
    @Column(nullable = false, unique = true)
    private String nit;

    @Column(nullable = false)
    private String nombre;

    @Column
    private String direccion;

    @Column
    private String telefono;

    @OneToMany(mappedBy = "ips", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<IpsServicioSaludEntity> servicios;
    
    @ManyToOne
    @JoinColumn(name = "eps_id", nullable = false)
    private EpsEntity eps;
    
    @OneToMany(mappedBy = "ips", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<TrabajaIPSEntity> medicosQueTrabajan;
    

    // Constructors
    public IpsEntity() {
    }

    public IpsEntity(String nit, String nombre, String direccion, String telefono) {
        this.nit = nit;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    // Getters and Setters
    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}

