package sistrans.proyecto.proyecto1sistrans.logic;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import sistrans.proyecto.proyecto1sistrans.model.IpsEntity;

// RF1 Registrar una IPS

public interface IPSLogic extends JpaRepository<IpsEntity, String> {
    @Query(value = "SELECT * FROM ips", nativeQuery = true)
    Collection<IpsEntity> darIps();
    @Query(value = "SELECT * FROM ips WHERE nit = :nit", nativeQuery = true)
    IpsEntity darIpsPorNit(@Param("nit") String nit);

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO ips (nit,nombre,direccion,telefono,eps_id) VALUES (:nit,:nombre,:direccion,:telefono,:eps_id)", nativeQuery= true)
    void insertIps(@Param("nit") String nit, @Param("nombre") String nombre, @Param("direccion") String direccion, @Param("telefono") String telefono, @Param("eps_id") Long eps_id);
  
    
}
