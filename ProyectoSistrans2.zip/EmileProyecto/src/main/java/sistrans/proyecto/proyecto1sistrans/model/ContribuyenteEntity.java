package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "contribuyente")
public class ContribuyenteEntity extends AfiliadoEntity {

    @Column
    private String empresa;

    // Constructors
    public ContribuyenteEntity() {}

    public ContribuyenteEntity(String empresa) {
        this.empresa = empresa;
    }

    // Getter and Setter
    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }
}
