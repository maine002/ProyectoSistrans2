package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

//Para el RF8

@Entity
@Table(name = "prestacion_servicio")
public class PrestacionServicioEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "prestacion_seq_gen")
    @SequenceGenerator(name = "prestacion_seq_gen", sequenceName = "PRESTACION_SEQ", allocationSize = 1)
    private Long id;

    @Column(name = "afiliado_id", nullable = false)
    private Long afiliadoId;

    @Column(name = "servicio_id", nullable = false)
    private Long servicioId;

    @Column(name = "medico_id", nullable = false)
    private String medicoId;

    @Column(name = "ips_nit", nullable = false)
    private String ipsNit;

    @Column(nullable = false)
    private LocalDate fecha;

    @Column(nullable = false)
    private LocalTime hora;

    // Constructor 
    public PrestacionServicioEntity() {}

    // Getters y Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public Long getAfiliadoId() {
        return afiliadoId;
    }
    public void setAfiliadoId(Long afiliadoId) {
        this.afiliadoId = afiliadoId;
    }

    public Long getServicioId() {
        return servicioId;
    }
    public void setServicioId(Long servicioId) {
        this.servicioId = servicioId;
    }

    public String getMedicoId() {
        return medicoId;
    }
    public void setMedicoId(String medicoId) {
        this.medicoId = medicoId;
    }

    public String getIpsNit() {
        return ipsNit;
    }
    public void setIpsNit(String ipsNit) {
        this.ipsNit = ipsNit;
    }

    public LocalDate getFecha() {
        return fecha;
    }
    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHora() {
        return hora;
    }
    public void setHora(LocalTime hora) {
        this.hora = hora;
    }
}
