package sistrans.proyecto.proyecto1sistrans.logic;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import sistrans.proyecto.proyecto1sistrans.model.ServicioSaludEntity;


// RF2 Registrar un servicio de salud

public interface ServicioSaludLogic extends JpaRepository<ServicioSaludEntity, Long> {
    @Query("SELECT s FROM ServicioSaludEntity s")
    Collection<ServicioSaludEntity> darServicioSalud();

    @Modifying
    @Transactional
    @Query(value = """
        INSERT INTO servicio_salud (id, nombre, fecha, hora, tipo_servicio)
        VALUES (SERVICIO_SEQ.NEXTVAL, :nombre, :fecha, :hora, :tipoServicio)
    """, nativeQuery = true)
    void insertarServicio(
        @Param("nombre") String nombre,
        @Param("fecha") Date fecha,
        @Param("hora") Time hora,
        @Param("tipoServicio") String tipoServicio
    );
      
//RFC3 ServicioSaludLogic
    @Query(value = """
        SELECT servicio_id,
            COUNT(CASE WHEN realizado = 1 THEN 1 END) AS usados,
            COUNT(*) AS disponibles,
            CASE 
                WHEN COUNT(*) = 0 THEN 0
                ELSE ROUND(COUNT(CASE WHEN realizado = 1 THEN 1 END) / COUNT(*), 2)
            END AS indice_uso
        FROM agendamiento
        WHERE fecha BETWEEN :fechaInicio AND :fechaFin
        GROUP BY servicio_id
        ORDER BY indice_uso DESC
    """, nativeQuery = true)
    List<Object[]> indiceUsoServicios(
    @Param("fechaInicio") LocalDate fechaInicio,
    @Param("fechaFin") LocalDate fechaFin
    );

//RFC2
@Query(value = """
    SELECT a.servicio_id, COUNT(*) AS cantidad
    FROM agendamiento a
    WHERE a.fecha BETWEEN :fechaInicio AND :fechaFin
    GROUP BY a.servicio_id
    ORDER BY cantidad DESC
    FETCH FIRST 20 ROWS ONLY
""", nativeQuery = true)
List<Object[]> serviciosMasSolicitados(
    @Param("fechaInicio") LocalDate fechaInicio,
    @Param("fechaFin") LocalDate fechaFin
);

}
