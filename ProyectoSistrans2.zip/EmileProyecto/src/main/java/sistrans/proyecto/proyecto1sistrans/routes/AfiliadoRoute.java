package sistrans.proyecto.proyecto1sistrans.routes;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import sistrans.proyecto.proyecto1sistrans.logic.AfiliadoLogic;

@RestController
@RequestMapping("/afiliados")
public class AfiliadoRoute {

    @Autowired
    private AfiliadoLogic afiliadoLogic;

    @PostMapping("/registrar")
    public String registrarAfiliado(
            @RequestParam Long id,
            @RequestParam String nombre,
            @RequestParam String tipoDocumento,
            @RequestParam String numeroDocumento,
            @RequestParam LocalDate fechaNacimiento,
            @RequestParam String direccion,
            @RequestParam String telefono,
            @RequestParam Long epsId) {
        try {
            afiliadoLogic.insertAfiliado(id, nombre, tipoDocumento, numeroDocumento, fechaNacimiento, direccion, telefono, epsId);
            return "Afiliado registrado exitosamente.";
        } catch (Exception e) {
            return "Error al registrar afiliado: " + e.getMessage();
        }
    }
}

