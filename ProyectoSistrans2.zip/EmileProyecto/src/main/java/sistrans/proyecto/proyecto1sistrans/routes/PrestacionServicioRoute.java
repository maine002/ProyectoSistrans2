package sistrans.proyecto.proyecto1sistrans.routes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import sistrans.proyecto.proyecto1sistrans.logic.PrestacionServicioLogic;
import java.sql.Date;


 // Para el RF8
 
@RestController
@RequestMapping("/prestaciones")
public class PrestacionServicioRoute {

    @Autowired
    private PrestacionServicioLogic prestacionServicioLogic;

    @PostMapping("/registrar")
    public void registrarPrestacion(
            @RequestParam Long afiliadoId,
            @RequestParam Long servicioId,
            @RequestParam String medicoId,
            @RequestParam String ipsNit,
            @RequestParam Date fecha,
            @RequestParam String hora
    ) {
        prestacionServicioLogic.insertarPrestacion(afiliadoId, servicioId, medicoId, ipsNit, fecha, hora);
    }
}
