package sistrans.proyecto.proyecto1sistrans.logic;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import sistrans.proyecto.proyecto1sistrans.model.MedicoEntity;

// RF4 Registrar un Médico

public interface MedicoLogic extends JpaRepository<MedicoEntity, String> {

    @Query(value = "SELECT * FROM medico", nativeQuery = true)
    Collection<MedicoEntity> darMedicos();

    @Query(value = "SELECT * FROM medico WHERE numero_registro = :numeroRegistro", nativeQuery = true)
    MedicoEntity darMedicoPorRegistro(@Param("numeroRegistro") String numeroRegistro);

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO medico (numero_registro, nombre, tipo_documento, numero_documento, especialidad) VALUES (:numeroRegistro, :nombre, :tipoDocumento, :numeroDocumento, :especialidad)", nativeQuery = true)
    void insertMedico(
        @Param("numeroRegistro") String numeroRegistro,
        @Param("nombre") String nombre,
        @Param("tipoDocumento") String tipoDocumento,
        @Param("numeroDocumento") String numeroDocumento,
        @Param("especialidad") String especialidad
    );
}
