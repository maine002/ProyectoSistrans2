package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "orden_servicio")
public class OrdenServicioEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ordenId;

    @Column(nullable = false)
    private LocalDate fecha;

    @Column(nullable = false)
    private String estado;

    @Column(nullable = false)
    private Long ordenPreviaId;

    @OneToMany(mappedBy = "orden", cascade = CascadeType.ALL)
    private List<AgendamientoEntity> agendamientos;
    
    @OneToOne
    @JoinColumn(name = "afiliado_id", nullable = false)
    private AfiliadoEntity afiliado;
    
    @OneToOne
    @JoinColumn(name = "medico_id", nullable = false)
    private MedicoEntity medico;    

    // Constructors
    public OrdenServicioEntity() {
    }

    public OrdenServicioEntity(LocalDate fecha, String estado, Long ordenPreviaId) {
        this.fecha = fecha;
        this.estado = estado;
        this.ordenPreviaId = ordenPreviaId;
    }

    // Getters and Setters
    public Long getOrdenId() {
        return ordenId;
    }

    public void setOrdenId(Long ordenId) {
        this.ordenId = ordenId;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Long getOrdenPreviaId() {
        return ordenPreviaId;
    }

    public void setOrdenPreviaId(Long ordenPreviaId) {
        this.ordenPreviaId = ordenPreviaId;
    }
}

