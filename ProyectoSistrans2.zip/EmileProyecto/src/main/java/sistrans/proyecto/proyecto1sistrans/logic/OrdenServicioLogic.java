package sistrans.proyecto.proyecto1sistrans.logic;

import java.time.LocalDate;
import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import sistrans.proyecto.proyecto1sistrans.model.OrdenServicioEntity;

//RF6  REGISTRAR UNA ORDEN DE SERVICIO DE SALUD PARA UN AFILIADO POR PARTE DE UN MÉDICO

public interface OrdenServicioLogic extends JpaRepository<OrdenServicioEntity, Long> {

    @Query(value = "SELECT * FROM orden_servicio", nativeQuery = true)
    Collection<OrdenServicioEntity> darOrdenes();

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO orden_servicio (orden_id, fecha, estado, orden_previa_id, afiliado_id, medico_id) " +
                   "VALUES (:ordenId, :fecha, :estado, :ordenPreviaId, :afiliadoId, :medicoId)", nativeQuery = true)
    void insertOrden(
        @Param("ordenId") Long ordenId,
        @Param("fecha") LocalDate fecha,
        @Param("estado") String estado,
        @Param("ordenPreviaId") Long ordenPreviaId,
        @Param("afiliadoId") Long afiliadoId,
        @Param("medicoId") String medicoId
    );

    

}
