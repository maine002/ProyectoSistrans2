package sistrans.proyecto.proyecto1sistrans;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyecto1sistransApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proyecto1sistransApplication.class, args);
	}

}
