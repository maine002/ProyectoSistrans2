package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "hospitalizacion")
@DiscriminatorValue("hospitalizacion")
public class HospitalizacionEntity extends ServicioSaludEntity {

    @Column
    private String receta;

    public HospitalizacionEntity() {}

    public HospitalizacionEntity(String receta) {
        this.receta = receta;
    }

    public String getReceta() {
        return receta;
    }

    public void setReceta(String receta) {
        this.receta = receta;
    }
}
