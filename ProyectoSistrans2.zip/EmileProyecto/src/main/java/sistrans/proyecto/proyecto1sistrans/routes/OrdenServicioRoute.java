package sistrans.proyecto.proyecto1sistrans.routes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import sistrans.proyecto.proyecto1sistrans.logic.AgendamientoLogic;
import sistrans.proyecto.proyecto1sistrans.logic.OrdenServicioLogic;

//RF6 REGISTRAR UNA ORDEN DE SERVICIO DE SALUD PARA UN AFILIADO POR PARTE DE UN MÉDICO

@RestController
@RequestMapping("/ordenes")
public class OrdenServicioRoute {

    @Autowired
    private OrdenServicioLogic ordenServicioLogic;
    @Autowired
    private AgendamientoLogic agendamientoLogic;

    @PostMapping("/registrar")
    public String registrarOrden(
            @RequestParam Long ordenId,
            @RequestParam String fecha,
            @RequestParam String estado,
            @RequestParam Long ordenPreviaId,
            @RequestParam Long afiliadoId,
            @RequestParam String medicoId,
            @RequestParam String serviciosIds,
            @RequestParam Boolean realizado,
            @RequestParam String hora,
            @RequestParam(required = false) String observaciones) {  // aquí llegan los servicios como texto "[1,2]"
        try {

            LocalDate fechaParsed = LocalDate.parse(fecha);
            LocalTime horaParsed = LocalTime.parse(hora);

            ordenServicioLogic.insertOrden(ordenId, fechaParsed, estado, ordenPreviaId, afiliadoId, medicoId);
    
            List<Long> servicios = Arrays.stream(serviciosIds.replace("[", "").replace("]", "").split(","))
                                         .map(String::trim)
                                         .map(Long::parseLong)
                                         .collect(Collectors.toList());
    
            for (Long servicioId : servicios) {
                agendamientoLogic.insertAgendamiento(realizado, servicioId, fechaParsed, horaParsed, ordenId, observaciones);
            }
    
            return "Orden registrada exitosamente.";
        } catch (Exception e) {
            return "Error al registrar orden: " + e.getMessage();
        }
    }
}
