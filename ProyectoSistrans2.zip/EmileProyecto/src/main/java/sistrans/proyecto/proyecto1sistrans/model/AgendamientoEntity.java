package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "agendamiento")
public class AgendamientoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "orden_id", nullable = false)
    private OrdenServicioEntity orden;

    @ManyToOne
    @JoinColumn(name = "servicio_id", nullable = false)
    private ServicioSaludEntity servicio;

    @Column(nullable = false)
    private LocalDate fecha;

    @Column(nullable = false)
    private LocalTime hora;

    @Column(name = "realizado")
    private Boolean realizado;

    @Column(name = "observaciones")
    private String observaciones;

    // Constructors
    public AgendamientoEntity() {}

    public AgendamientoEntity(OrdenServicioEntity orden, ServicioSaludEntity servicio, LocalDate fecha, LocalTime hora) {
        this.orden = orden;
        this.servicio = servicio;
        this.fecha = fecha;
        this.hora = hora;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public OrdenServicioEntity getOrden() {
        return orden;
    }

    public void setOrden(OrdenServicioEntity orden) {
        this.orden = orden;
    }

    public ServicioSaludEntity getServicio() {
        return servicio;
    }

    public void setServicio(ServicioSaludEntity servicio) {
        this.servicio = servicio;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public Boolean getRealizado() {
        return realizado;
    }
    
    public void setRealizado(Boolean realizado) {
        this.realizado = realizado;
    }
}

