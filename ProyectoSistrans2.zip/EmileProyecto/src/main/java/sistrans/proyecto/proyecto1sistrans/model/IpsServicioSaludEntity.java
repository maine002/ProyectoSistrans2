package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "ips_servicio_salud")
public class IpsServicioSaludEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "ips_nit", nullable = false)
    private IpsEntity ips;

    @ManyToOne
    @JoinColumn(name = "servicio_id", nullable = false)
    private ServicioSaludEntity servicio;


    public IpsServicioSaludEntity() {}

    public IpsServicioSaludEntity(IpsEntity ips, ServicioSaludEntity servicio) {
        this.ips = ips;
        this.servicio = servicio;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public IpsEntity getIps() {
        return ips;
    }

    public void setIps(IpsEntity ips) {
        this.ips = ips;
    }

    public ServicioSaludEntity getServicio() {
        return servicio;
    }

    public void setServicio(ServicioSaludEntity servicio) {
        this.servicio = servicio;
    }

}
