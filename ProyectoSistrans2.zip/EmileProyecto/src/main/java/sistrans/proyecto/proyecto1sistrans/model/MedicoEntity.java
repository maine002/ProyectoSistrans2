package sistrans.proyecto.proyecto1sistrans.model;

import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name = "medico")
public class MedicoEntity {

    @Id
    @Column(nullable = false, unique = true)
    private String numeroRegistro;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private String tipoDocumento;

    @Column(nullable = false)
    private String numeroDocumento;

    @Column
    private String especialidad;

    @OneToOne(mappedBy = "medico")
    private OrdenServicioEntity orden;

    @OneToMany(mappedBy = "medico", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<TrabajaIPSEntity> trabajaIps;
    
    
    // Constructors
    public MedicoEntity() {
    }

    public MedicoEntity(String numeroRegistro, String nombre, String tipoDocumento, String numeroDocumento, String especialidad) {
        this.numeroRegistro = numeroRegistro;
        this.nombre = nombre;
        this.tipoDocumento = tipoDocumento;
        this.numeroDocumento = numeroDocumento;
        this.especialidad = especialidad;
    }

    // Getters and Setters
    public String getNumeroRegistro() {
        return numeroRegistro;
    }

    public void setNumeroRegistro(String numeroRegistro) {
        this.numeroRegistro = numeroRegistro;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
}

