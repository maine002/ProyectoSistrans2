package sistrans.proyecto.proyecto1sistrans.model;

import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name = "eps")
public class EpsEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nombre;

    @OneToMany(mappedBy = "eps")
    private List<AfiliadoEntity> afiliados;
    
    @OneToMany(mappedBy = "eps")
    private List<IpsEntity> ipsList;

    // Constructors
    public EpsEntity() {
    }

    public EpsEntity(String nombre) {
        this.nombre = nombre;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
