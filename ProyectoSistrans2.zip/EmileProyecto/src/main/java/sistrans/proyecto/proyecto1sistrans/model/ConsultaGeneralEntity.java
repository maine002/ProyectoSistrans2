package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "consulta_general")
@DiscriminatorValue("consulta_general")
public class ConsultaGeneralEntity extends ServicioSaludEntity {

    @Column
    private String receta;

    public ConsultaGeneralEntity() {}

    public ConsultaGeneralEntity(String receta) {
        this.receta = receta;
    }

    public String getReceta() {
        return receta;
    }

    public void setReceta(String receta) {
        this.receta = receta;
    }
}
