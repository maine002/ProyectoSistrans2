package sistrans.proyecto.proyecto1sistrans.logic;
import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import sistrans.proyecto.proyecto1sistrans.model.EpsEntity;


public interface EPSLogic extends JpaRepository<EpsEntity, Integer> {

    @Query(value = "SELECT * FROM eps", nativeQuery= true)
    Collection<EpsEntity> findAllEps();

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO eps (nombre) VALUES (:nombre)", nativeQuery= true)
    void insertEps(@Param("nombre") String nombre);

    
    
}

