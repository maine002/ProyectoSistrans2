package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "examen")
@DiscriminatorValue("examen")
public class ExamenEntity extends ServicioSaludEntity {

    @Column(nullable = false)
    private String tipo;

    public ExamenEntity() {}

    public ExamenEntity(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}

