package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "afiliado")
@Inheritance(strategy = InheritanceType.JOINED)
public class AfiliadoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private String tipoDocumento;

    @Column(nullable = false)
    private String numeroDocumento;

    @Column
    private LocalDate fechaNacimiento;

    @Column
    private String direccion;

    @Column(nullable = false)
    private String telefono;

    @ManyToOne
    @JoinColumn(name = "eps_id", nullable = false)
    private EpsEntity eps;

    @OneToOne(mappedBy = "afiliado")
    private OrdenServicioEntity orden;


    // Constructors
    public AfiliadoEntity() {}

    public AfiliadoEntity(String nombre, String tipoDocumento, String numeroDocumento, LocalDate fechaNacimiento, String direccion, String telefono) {
        this.nombre = nombre;
        this.tipoDocumento = tipoDocumento;
        this.numeroDocumento = numeroDocumento;
        this.fechaNacimiento = fechaNacimiento;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}

