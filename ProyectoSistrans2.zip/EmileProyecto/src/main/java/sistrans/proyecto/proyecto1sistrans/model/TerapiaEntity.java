package sistrans.proyecto.proyecto1sistrans.model;

import jakarta.persistence.*;

@Entity
@Table(name = "terapia")
@DiscriminatorValue("terapia")
public class TerapiaEntity extends ServicioSaludEntity {

    @Column(nullable = false)
    private String tipo;

    @Column
    private Integer numeroSesiones;

    public TerapiaEntity() {}

    public TerapiaEntity(String tipo, Integer numeroSesiones) {
        this.tipo = tipo;
        this.numeroSesiones = numeroSesiones;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Integer getNumeroSesiones() {
        return numeroSesiones;
    }

    public void setNumeroSesiones(Integer numeroSesiones) {
        this.numeroSesiones = numeroSesiones;
    }
}

