package sistrans.proyecto.proyecto1sistrans.routes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import sistrans.proyecto.proyecto1sistrans.logic.MedicoLogic;

@RestController
@RequestMapping("/medicos")
public class MedicoRoute {

    @Autowired
    private MedicoLogic medicoLogic;

    // RF4 - Registrar Médico
    @PostMapping("/registrar")
    public String registrarMedico(
            @RequestParam String numeroRegistro,
            @RequestParam String nombre,
            @RequestParam String tipoDocumento,
            @RequestParam String numeroDocumento,
            @RequestParam String especialidad) {
        try {
            medicoLogic.insertMedico(numeroRegistro, nombre, tipoDocumento, numeroDocumento, especialidad);
            return "Médico registrado exitosamente.";
        } catch (Exception e) {
            return "Error al registrar médico: " + e.getMessage();
        }
    }
}
