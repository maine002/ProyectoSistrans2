package sistrans.proyecto.proyecto1sistrans.routes;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import sistrans.proyecto.proyecto1sistrans.logic.IPSServicioSaludLogic;
import sistrans.proyecto.proyecto1sistrans.model.IpsServicioSaludEntity;
import org.springframework.web.bind.annotation.RequestParam;


//RF3 Asignar un servicio de salud a una IPS

@RestController
@RequestMapping("/ips-servicios")
class IpsServicioSaludRoute {
    @Autowired
    private IPSServicioSaludLogic logic;

    @GetMapping("/all")
    public Collection<IpsServicioSaludEntity> darAsignaciones() {
        return logic.getIpsServicioSalud();
    }

    @PostMapping("/asignar")
    public void asignarServicio(@RequestParam String ips_nit, @RequestParam Long servicio_id) {
        logic.insertIpsServicioSalud(ips_nit, servicio_id);
    }
}