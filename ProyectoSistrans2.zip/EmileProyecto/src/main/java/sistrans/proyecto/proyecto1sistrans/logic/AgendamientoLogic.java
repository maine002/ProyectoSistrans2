package sistrans.proyecto.proyecto1sistrans.logic;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import sistrans.proyecto.proyecto1sistrans.model.AgendamientoEntity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collection;
import java.util.List;

public interface AgendamientoLogic extends JpaRepository<AgendamientoEntity, Long> {
    @Query(value = """
        SELECT * FROM agendamiento
        WHERE servicio_id = :servicio_id
          AND fecha BETWEEN CURRENT_DATE AND CURRENT_DATE + 28
        ORDER BY fecha, hora
        """, nativeQuery = true)
    Collection<AgendamientoEntity> consultarDisponibilidadServicioProximas4Semanas(@Param("servicio_id") Long servicio_id);

    @Transactional(timeout = 30, isolation = Isolation.READ_COMMITTED)
    @Query(value = """
        SELECT a.* FROM agendamiento a
        JOIN orden_servicio o ON a.orden_id = o.orden_id
        WHERE a.servicio_id = :idServicio
          AND o.medico_id = :idMedico
          AND o.afiliado_id = :idAfiliado
          AND a.fecha BETWEEN :fechaInicio AND :fechaFin
        ORDER BY a.fecha, a.hora
    """, nativeQuery = true)
    Collection<AgendamientoEntity> consultarAgendaConFiltros(
        @Param("idServicio") Long idServicio,
        @Param("idMedico") String idMedico,
        @Param("idAfiliado") Long idAfiliado,
        @Param("fechaInicio") LocalDate fechaInicio,
        @Param("fechaFin") LocalDate fechaFin
    );

    // Para el RF7 

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO agendamiento (orden_id, servicio_id, fecha, hora, realizado, observaciones) " +
                "VALUES (:orden_id, :servicio_id, :fecha, :hora, :realizado, :observaciones)", nativeQuery = true)
    void insertAgendamiento(
        @Param("realizado") Boolean realizado,
        @Param("servicio_id") Long servicio_id,
        @Param("fecha") LocalDate fecha,
        @Param("hora") LocalTime hora,
        @Param("orden_id") Long orden_id,
        @Param("observaciones") String observaciones
    );

    @Modifying
    @Transactional
    @Query(value = "UPDATE agendamiento SET realizado = :realizado WHERE orden_id = :orden_id AND servicio_id = :servicio_id AND id = :id", nativeQuery = true)
    void updateRealizado(
        @Param("realizado") Boolean realizado,
        @Param("servicio_id") Long servicio_id,
        @Param("orden_id") Long orden_id,
        @Param("id") Long id
    );
    
    
    // Para el RF9
    @Query(value = "SELECT * FROM agendamiento WHERE id = :idEspacio", nativeQuery = true)
    AgendamientoEntity buscarEspacioPorId(@Param("idEspacio") Long idEspacio);
    
    @Query(value = """
        SELECT * FROM agendamiento
        WHERE servicio_id = :servicioId
          AND fecha = TO_DATE(:fecha, 'YYYY-MM-DD')
          AND hora = TO_TIMESTAMP(:hora, 'HH24:MI:SS')
    """, nativeQuery = true)
    Collection<AgendamientoEntity> buscarAgendamientosPorServicioFechaHora(
        @Param("servicioId") Long servicioId,
        @Param("fecha") String fecha,
        @Param("hora") String hora
    );
    
//RFC5
@Transactional(timeout = 30, isolation = Isolation.SERIALIZABLE)
@Query(value = """
    SELECT a.* FROM agendamiento a
    JOIN orden_servicio o ON a.orden_id = o.orden_id
    WHERE a.servicio_id = :idServicio
      AND o.medico_id = :idMedico
      AND o.afiliado_id = :idAfiliado
      AND a.fecha BETWEEN :fechaInicio AND :fechaFin
    ORDER BY a.fecha, a.hora
""", nativeQuery = true)
Collection<AgendamientoEntity> consultarAgendaConFiltrosSerializable(
    @Param("idServicio") Long idServicio,
    @Param("idMedico") String idMedico,
    @Param("idAfiliado") Long idAfiliado,
    @Param("fechaInicio") LocalDate fechaInicio,
    @Param("fechaFin") LocalDate fechaFin
);

//RFC4 agendamientoLogic
@Query(value = """
    SELECT s.nombre AS nombre_servicio, a.fecha AS fecha_servicio, m.nombre AS nombre_medico, ips.nombre AS nombre_ips
    FROM agendamiento a
    JOIN servicio_salud s ON a.servicio_id = s.id
    JOIN orden_servicio o ON a.orden_id = o.orden_id
    JOIN medico m ON o.medico_id = m.numero_registro
    JOIN ips_servicio_salud iss ON s.id = iss.servicio_id
    JOIN ips ON iss.ips_nit = ips.nit
    WHERE o.afiliado_id = :afiliadoId
    AND a.fecha BETWEEN :fechaInicio AND :fechaFin
    ORDER BY a.fecha
""", nativeQuery = true)
List<Object[]> obtenerUtilizacionServiciosAfiliado(
    @Param("afiliadoId") Long afiliadoId,
    @Param("fechaInicio") LocalDate fechaInicio,
    @Param("fechaFin") LocalDate fechaFin
);

}

