package sistrans.proyecto.proyecto1sistrans;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto1sistransApplicationTests {

	@Test
	void contextLoads() {
	}

}
